setwd("C:\\Users\\Lenovo\\Desktop\\IT24102375")

#Q1
#--mean 45 minutes and standard deviation 2 minutes

#Part 01- Random sample of size 25
baking_times <- rnorm(25, mean=45, sd=2)
baking_times

#Part 02 - Test average baking time is less than 46 minutes at a 5% level of significance.
#Null hypothesis H0: mu = 46
#Alternative hypothesis H1: mu < 46
#So, ------  Hypothesis: H0: mu >= 46 vs H1: mu < 46
t.test(baking_times, mu=46, alternative="less")


setwd("C:\\Users\\Lenovo\\Desktop\\IT24102375 Lab 06")
#Exersice
#01
#i)
#Binomial Distribution
#n=50  , p = 0.85
#ii)
pbinom(46, 50, 0.85, lower.tail = FALSE)
setwd("C:\Users\Lenovo\Desktop\IT24102375 Lab 06")
#01
#i)
#Binomial Distribution
#n=50  , p = 0.85
#ii)
pbinom(46, 50, 0.85, lower.tail = FALSE)
#02
#i)
# number of calls received in one hour
#ii)
#Poisson Distribution
#iii)
dpois(15, 12)
